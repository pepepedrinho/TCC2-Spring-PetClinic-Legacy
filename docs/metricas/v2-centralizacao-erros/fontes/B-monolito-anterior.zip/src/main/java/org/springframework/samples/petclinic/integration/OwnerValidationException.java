package org.springframework.samples.petclinic.integration;

// Componente novo da integração: traduz rejeições HTTP 400 do serviço Owners para o fluxo do legado.
@org.springframework.web.bind.annotation.ResponseStatus(value = org.springframework.http.HttpStatus.BAD_REQUEST,
        reason = "Invalid owner data")
public class OwnerValidationException extends RuntimeException {
}
