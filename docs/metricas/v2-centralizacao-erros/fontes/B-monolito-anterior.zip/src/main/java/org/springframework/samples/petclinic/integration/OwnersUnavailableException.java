package org.springframework.samples.petclinic.integration;

// Componente novo da integração: transporta a causa de indisponibilidade ou resposta inválida do serviço Owners.
public class OwnersUnavailableException extends RuntimeException {
    public OwnersUnavailableException(Throwable cause) {
        super("Owners service unavailable", cause);
    }
}
