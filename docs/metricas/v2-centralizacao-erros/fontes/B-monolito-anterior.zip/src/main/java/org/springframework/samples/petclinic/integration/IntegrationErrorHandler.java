package org.springframework.samples.petclinic.integration;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

// Componente novo da coexistência: apresenta a página de indisponibilidade com HTTP 503 quando o serviço
// Owners não responde.
@ControllerAdvice
public class IntegrationErrorHandler {
    @ExceptionHandler(OwnersUnavailableException.class)
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public String unavailable() {
        return "ownersUnavailable";
    }
}
