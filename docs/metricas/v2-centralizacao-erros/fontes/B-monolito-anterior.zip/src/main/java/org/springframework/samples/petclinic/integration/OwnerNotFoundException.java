package org.springframework.samples.petclinic.integration;

// Componente novo da integração: sinaliza HTTP 404 para Owner ausente ou Pet sem vínculo com o Owner solicitado.
@org.springframework.web.bind.annotation.ResponseStatus(value = org.springframework.http.HttpStatus.NOT_FOUND,
        reason = "Owner or Pet not found")
public class OwnerNotFoundException extends RuntimeException {
}
