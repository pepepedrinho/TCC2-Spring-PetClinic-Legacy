/*
 * Copyright 2002-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.samples.petclinic.owner;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

/**
 * @author Juergen Hoeller
 * @author Ken Krebs
 * @author Arjen Poutsma
 */
@Controller
@RequestMapping("/owners/{ownerId}")
class PetController {

    private static final String VIEWS_PETS_CREATE_OR_UPDATE_FORM = "pets/createOrUpdatePetForm";

    private final PetRepository petRepository;

    private final OwnerRepository ownerRepository;

    @Autowired
    public PetController(PetRepository petRepository, OwnerRepository ownerRepository) {
        this.petRepository = petRepository;
        this.ownerRepository = ownerRepository;
    }

    @ModelAttribute("types")
    public Collection<PetType> populatePetTypes() {
        return this.petRepository.findPetTypes();
    }

    @ModelAttribute("owner")
    public Owner findOwner(@PathVariable("ownerId") int ownerId) {
        return this.ownerRepository.findById(ownerId);
    }

    @InitBinder("owner")
    public void initOwnerBinder(WebDataBinder webDataBinder) {
        webDataBinder.setDisallowedFields("id");
    }

    // ============================================================
    // IMPLEMENTAÇÃO ORIGINAL — MONÓLITO (branch 1.5.x)
    // Origem: src/main/java/org/springframework/samples/petclinic/owner/PetController.java: initPetBinder
    // ============================================================
    // @InitBinder("pet")
    //     public void initPetBinder(WebDataBinder dataBinder) {
    //         dataBinder.setValidator(new PetValidator());
    //     }
    // ============================================================
    // IMPLEMENTAÇÃO ATUAL — STRANGLER FIG V2
    // O fluxo MVC da V2 restringe o binding e valida o vínculo local com o Owner remoto.
    // ============================================================

    @InitBinder("pet")
    public void initPetBinder(WebDataBinder webDataBinder) {
        webDataBinder.setValidator(new PetValidator());
        webDataBinder.setAllowedFields("name", "birthDate", "type");
    }

    @GetMapping("/pets/new")
    public String initCreationForm(Owner owner, ModelMap modelMap) {
        Pet pet = new Pet();
        owner.addPet(pet);
        modelMap.put("pet", pet);
        return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
    }

    @PostMapping("/pets/new")
    public String processCreationForm(Owner owner, @Valid Pet pet, BindingResult bindingResult, ModelMap modelMap) {
        if (StringUtils.hasLength(pet.getName()) && pet.isNew() && owner.getPet(pet.getName(), true) != null) {
            bindingResult.rejectValue("name", "duplicate", "already exists");
        }
        owner.addPet(pet);
        if (bindingResult.hasErrors()) {
            modelMap.put("pet", pet);
            return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
        } else {
            this.petRepository.save(pet);
            return "redirect:/owners/{ownerId}";
        }
    }

    // ============================================================
    // IMPLEMENTAÇÃO ORIGINAL — MONÓLITO (branch 1.5.x)
    // Origem: src/main/java/org/springframework/samples/petclinic/owner/PetController.java: initUpdateForm
    // ============================================================
    // @GetMapping("/pets/{petId}/edit")
    //     public String initUpdateForm(@PathVariable("petId") int petId, ModelMap model) {
    //         Pet pet = this.pets.findById(petId);
    //         model.put("pet", pet);
    //         return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
    //     }
    // ============================================================
    // IMPLEMENTAÇÃO ATUAL — STRANGLER FIG V2
    // O fluxo MVC da V2 restringe o binding e valida o vínculo local com o Owner remoto.
    // ============================================================

    @GetMapping("/pets/{petId}/edit")
    public String initUpdateForm(@PathVariable("ownerId") int ownerId, @PathVariable("petId") int petId, Owner owner,
            ModelMap modelMap) {
        Pet pet = this.petRepository.findById(petId);
        checkOwnership(pet, ownerId);
        pet.setOwner(owner);
        modelMap.put("pet", pet);
        return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
    }

    // ============================================================
    // IMPLEMENTAÇÃO ORIGINAL — MONÓLITO (branch 1.5.x)
    // Origem: src/main/java/org/springframework/samples/petclinic/owner/PetController.java: processUpdateForm
    // ============================================================
    // @PostMapping("/pets/{petId}/edit")
    //     public String processUpdateForm(@Valid Pet pet, BindingResult result, Owner owner, ModelMap model) {
    //         if (result.hasErrors()) {
    //             pet.setOwner(owner);
    //             model.put("pet", pet);
    //             return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
    //         } else {
    //             owner.addPet(pet);
    //             this.pets.save(pet);
    //             return "redirect:/owners/{ownerId}";
    //         }
    //     }
    // ============================================================
    // IMPLEMENTAÇÃO ATUAL — STRANGLER FIG V2
    // O fluxo MVC da V2 restringe o binding e valida o vínculo local com o Owner remoto.
    // ============================================================

    @PostMapping("/pets/{petId}/edit")
    public String processUpdateForm(@PathVariable("petId") int petId, @Valid Pet pet, BindingResult bindingResult,
            Owner owner,
            ModelMap modelMap) {
        checkOwnership(this.petRepository.findById(petId), owner.getId());
        pet.setId(petId);
        if (bindingResult.hasErrors()) {
            pet.setOwner(owner);
            modelMap.put("pet", pet);
            return VIEWS_PETS_CREATE_OR_UPDATE_FORM;
        } else {
            owner.addPet(pet);
            this.petRepository.save(pet);
            return "redirect:/owners/{ownerId}";
        }
    }

    // Auxiliar novo da V2: impede acesso ao Pet por um Owner diferente.
    private void checkOwnership(Pet pet, Integer ownerId) {
        if (pet == null || !ownerId.equals(pet.getOwnerId())) {
            // Antes havia uma exceção exclusiva; o handler central agora define o erro de vínculo.
            throw org.springframework.samples.petclinic.integration.IntegrationErrorHandler.notFound();
        }
    }
}
